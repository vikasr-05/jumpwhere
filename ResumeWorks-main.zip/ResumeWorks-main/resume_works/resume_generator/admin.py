from django.contrib import admin
from .models import *

admin.site.register(CodingSkill)
admin.site.register(Tool)
admin.site.register(Designation)
admin.site.register(Project)
admin.site.register(Employee)


# Register your models here.
